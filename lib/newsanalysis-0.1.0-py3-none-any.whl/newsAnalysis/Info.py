class Info:

    def __init__(self):
        pass

    def database(self, databaseName, host, port, user, password):
        self.database = databaseName
        self.host = host
        self.port = port
        self.user = user
        self.password = password



