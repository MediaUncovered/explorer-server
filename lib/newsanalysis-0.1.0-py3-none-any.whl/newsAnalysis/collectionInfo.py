from Collection import Collection

class CollectionInfo(object):

    def __init__(self, path=''):
        collection = Collection(path)
        self.newspaper = newspaperName(path)
        self.nr_articles = collection.count()

    def newspaperName(self, path):
        filename = path.split('/')[-1]
        newspaper = filename.split('_')[:-1]
        return ' '.join(newspaper)





